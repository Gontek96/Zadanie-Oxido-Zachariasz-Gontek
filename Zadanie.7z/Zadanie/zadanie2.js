//Zmienne
const artykul ='./artykul.html';
const szablon_html ='./szablon.html';
const axios = require('axios');
const { count } = require('console');
const { start } = require('repl');
//const apiKey = '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';

let message = '';
let ans=null;

async function useAPI_Chat() 
{
  const request = {
    model: 'gpt-4',
    messages: [{ role: 'user', content: message}]
  };

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      request,
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        }
      }
    );

    //odpowidź    
    ans = response.data.choices[0].message.content;

    const fs = require('fs');
    const dataWrite = ans;

    fs.writeFile(path_Html, dataWrite, (err) => {
      if (err) {
        console.error('Błąd zapisu do pliku:', err);
      } else console.error('Zapisano:');
    });

  } 
  catch (error) {
    console.error('Error calling GPT-3 API:', error.response ? error.response.data : error.message);
  }
  return;
}

function Start()
{
message = 'wygeneruj szblon HTML'
}
Start();